import csv,hashlib,json,math,pathlib
p=pathlib.Path(__file__).parent
rows=list(csv.DictReader((p/'synthetic_trials.csv').open()))
by={g:[int(r['purchase']) for r in rows if r['arm']==g] for g in ['control','treatment']}
rates={g:sum(x)/len(x) for g,x in by.items()}
result={'illustrative_only':True,'estimand':'ITT','window':'7d','denominator_unit':'eligible_randomized_users','n_by_arm':{g:len(x) for g,x in by.items()},'rates':rates,'difference':rates['treatment']-rates['control'],'source_sha256':hashlib.sha256((p/'synthetic_trials.csv').read_bytes()).hexdigest(),'verification':'synthetic independent recomputation; NOT a third-party attestation'}
(p/'mre_output.json').write_text(json.dumps(result,indent=2))
assert len(by['control'])==100 and len(by['treatment'])==100
assert abs(result['difference']-0.02)<1e-12
print(json.dumps(result,indent=2))
